import 'dart:io';

import 'package:dio/dio.dart';
import 'package:eClassify/app_config.dart';
import 'package:eClassify/data/model/data_output.dart';
import 'package:eClassify/data/model/item/item_model.dart';
import 'package:eClassify/data/model/item_filter_model.dart';
import 'package:eClassify/utils/api.dart';
import 'package:eClassify/utils/background_upload_utility.dart';
import 'package:eClassify/utils/my_ads_refresh.dart';
import 'package:eClassify/utils/reel_feed_refresh.dart';
import 'package:eClassify/utils/reel_upload_tracker.dart';
import 'package:path/path.dart' as path;

List<ItemModel> _itemModelsFromGetItemResponse(Map<String, dynamic> response) {
  final data = response['data'];
  if (data is List) {
    return data
        .map((e) => ItemModel.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }
  if (data is Map && data['data'] is List) {
    return (data['data'] as List)
        .map((e) => ItemModel.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }
  return [];
}

int _itemTotalFromGetItemResponse(Map<String, dynamic> response) {
  final data = response['data'];
  if (data is Map) {
    return data['total'] ?? 0;
  }
  return 0;
}

void _applyListingLocation({
  required Map<String, dynamic> parameters,
  int? radius,
  double? latitude,
  double? longitude,
  String? city,
  int? areaId,
  String? country,
  String? state,
}) {
  if (radius != null) {
    parameters['radius'] = radius;
    if (latitude != null && longitude != null) {
      parameters['latitude'] = latitude;
      parameters['longitude'] = longitude;
    }
    parameters.remove('city');
    parameters.remove('area');
    parameters.remove('area_id');
    parameters.remove('country');
    parameters.remove('state');
  } else {
    if (city != null && city.isNotEmpty) parameters['city'] = city;
    if (areaId != null) parameters['area_id'] = areaId;
    if (country != null && country.isNotEmpty) parameters['country'] = country;
    if (state != null && state.isNotEmpty) parameters['state'] = state;
  }
}

ItemModel _itemModelFromMutationResponse(Map<String, dynamic> response) {
  final data = response['data'];
  if (data is List && data.isNotEmpty) {
    return ItemModel.fromJson(
      Map<String, dynamic>.from(data.first as Map),
    );
  }
  if (data is Map) {
    return ItemModel.fromJson(Map<String, dynamic>.from(data));
  }
  throw Exception('Invalid item create/update response');
}

class ItemRepository {
  Future<ItemModel> createItem(
    Map<String, dynamic> itemDetails,
    File mainImage,
    List<File>? otherImages,
  ) async {
    try {
      Map<String, dynamic> parameters = {};
      parameters.addAll(itemDetails);

      // Main image
      //MultipartFile image = await MultipartFile.fromFile(mainImage.path);
      MultipartFile image = await MultipartFile.fromFile(mainImage.path,
          filename: path.basename(mainImage.path));

      if (otherImages != null && otherImages.isNotEmpty) {
        List<Future<MultipartFile>> futures = otherImages.map((imageFile) {
          //return MultipartFile.fromFile(imageFile.path);
          return MultipartFile.fromFile(imageFile.path,
              filename: path.basename(imageFile.path));
        }).toList();

        List<MultipartFile> galleryImages = await Future.wait(futures);

        if (galleryImages.isNotEmpty) {
          parameters["gallery_images"] = galleryImages;
        }
      }

      parameters.addAll({
        "image": image,
        "show_only_to_premium": 1,
      });

      Map<String, dynamic> response = await Api.post(
        url: Api.addItemApi,
        parameter: parameters, /* useAuthToken: true*/
      );

      return _itemModelFromMutationResponse(response);
    } catch (e) {
      rethrow;
    }
  }

  /// Queues large media files for [upload-media] after the item row exists (2.14).
  Future<bool> scheduleBackgroundMediaUpload({
    required ItemModel item,
    Map<String, String>? files,
  }) async {
    if (files == null || files.isEmpty) return false;
    final taskId = await BackgroundUploadUtility.uploadMedia(
      itemId: item.id.toString(),
      files: files,
    );
    if (taskId != null && AppConfig.enableReelUploadTrackerV214) {
      await ReelUploadTracker.track(
        itemId: item.id.toString(),
        files: files,
        taskId: taskId,
      );
      if (AppConfig.enableMyAdsRefreshAfterReelUploadV214) {
        MyAdsRefresh.revision.value++;
      }
      if (AppConfig.enableReelFeedRefreshAfterReelUploadV214) {
        ReelFeedRefresh.revision.value++;
      }
    }
    return taskId != null;
  }

  Future<DataOutput<ItemModel>> fetchMyFeaturedItems({int? page}) async {
    try {
      Map<String, dynamic> parameters = {"status": "featured", "page": page};

      Map<String, dynamic> response = await Api.get(
        url: Api.getMyItemApi,
        queryParameters: parameters, /*useAuthToken: true*/
      );
      List<ItemModel> itemList = (response['data']['data'] as List)
          .map((element) => ItemModel.fromJson(element))
          .toList();

      return DataOutput(
          total: response['data']['total'] ?? 0, modelList: itemList);
    } catch (e) {
      rethrow;
    }
  }

  Future<DataOutput<ItemModel>> fetchMyItems(
      {String? getItemsWithStatus, int? page}) async {
    try {
      Map<String, dynamic> parameters = {
        if (getItemsWithStatus != null) "status": getItemsWithStatus,
        if (page != null) Api.page: page
      };

      if (parameters['status'] == "") parameters.remove('status');
      Map<String, dynamic> response = await Api.get(
        url: Api.getMyItemApi,
        queryParameters: parameters, /*useAuthToken: true*/
      );
      List<ItemModel> itemList = (response['data']['data'] as List)
          .map((element) => ItemModel.fromJson(element))
          .toList();

      return DataOutput(
          total: response['data']['total'] ?? 0, modelList: itemList);
    } catch (e) {
      rethrow;
    }
  }

  Future<DataOutput<ItemModel>> fetchItemFromItemId(int id) async {
    Map<String, dynamic> parameters = {
      Api.id: id,
    };

    Map<String, dynamic> response = await Api.get(
      url: Api.getItemApi,
      queryParameters: parameters,
    );

    final modelList = _itemModelsFromGetItemResponse(response);

    return DataOutput(total: modelList.length, modelList: modelList);
  }

  Future<DataOutput<ItemModel>> fetchItemFromItemSlug(String slug) async {
    Map<String, dynamic> parameters = {
      Api.slug: slug,
    };

    Map<String, dynamic> response = await Api.get(
      url: Api.getItemApi,
      queryParameters: parameters,
    );

    final modelList = _itemModelsFromGetItemResponse(response);

    return DataOutput(total: modelList.length, modelList: modelList);
  }

  Future<Map> changeMyItemStatus(
      {required int itemId, required String status, int? userId}) async {
    Map response = await Api.post(url: Api.updateItemStatusApi, parameter: {
      Api.status: status,
      Api.itemId: itemId,
      Api.soldTo: userId
    });
    return response;
  }

  Future<Map> createFeaturedAds({required int itemId}) async {
    Map response = await Api.post(url: Api.makeItemFeaturedApi, parameter: {
      "item_id": itemId,
    });
    return response;
  }

  Future<DataOutput<ItemModel>> fetchItemFromCatId(
      {required int categoryId,
      required int page,
      String? search,
      String? sortBy,
      String? country,
      String? state,
      String? city,
      int? areaId,
      int? radius,
      double? latitude,
      double? longitude,
      int? excludedItemId,
      ItemFilterModel? filter}) async {
    Map<String, dynamic> parameters = {
      Api.categoryId: categoryId,
      Api.page: page,
    };

    if (excludedItemId != null) {
      parameters[Api.excludedItemId] = excludedItemId;
    }

    if (filter != null) {
      parameters.addAll(filter.toQueryParameters());

      if (filter.radius != null) {
        _applyListingLocation(
          parameters: parameters,
          radius: filter.radius,
          latitude: filter.latitude,
          longitude: filter.longitude,
        );
      } else {
        _applyListingLocation(
          parameters: parameters,
          city: city ?? filter.city,
          areaId: areaId ?? filter.areaId,
          country: country ?? filter.country,
          state: state ?? filter.state,
        );
      }

      if (filter.areaId == null && areaId == null) {
        parameters.remove('area_id');
      }

      parameters.remove('area');

      if (filter.customFields != null) {
        filter.customFields!.forEach((key, value) {
          if (value is List) {
            parameters[key] = value.map((v) => v.toString()).join(',');
          } else {
            parameters[key] = value.toString();
          }
        });
      }
    } else {
      _applyListingLocation(
        parameters: parameters,
        radius: radius,
        latitude: latitude,
        longitude: longitude,
        city: city,
        areaId: areaId,
        country: country,
        state: state,
      );
    }

    if (search != null && search.isNotEmpty) {
      parameters[Api.search] = search;
    }

    if (sortBy != null && sortBy.isNotEmpty) {
      parameters[Api.sortBy] = sortBy;
    }

    Map<String, dynamic> response =
        await Api.get(url: Api.getItemApi, queryParameters: parameters);

    final items = _itemModelsFromGetItemResponse(response);

    return DataOutput(
        total: _itemTotalFromGetItemResponse(response), modelList: items);
  }

/*  Future<DataOutput<ItemModel>> fetchItemFromCatId(
      {required int categoryId,
      required int page,
      String? search,
      String? sortBy,
      String? country,
      String? state,
      String? city,
      int? areaId,
      ItemFilterModel? filter}) async {
    Map<String, dynamic> parameters = {
      Api.categoryId: categoryId,
      Api.page: page,
      if (city != null && city != "") 'city': city,
      if (areaId != null && areaId != "") 'area_id': areaId,
      if (country != null && country != "") 'country': country,
      if (state != null && state != "") 'state': state,
    };

    if (filter != null) {
      parameters.addAll(filter.toMap());

      if (filter.areaId == null) {
        parameters.remove('area_id');
      }

      parameters.remove('area');

      // Add custom fields separately to the parameters
      if (filter.customFields != null) {
        filter.customFields!.forEach((key, value) {
          if (value is List) {
            parameters[key] = value.map((v) => v.toString()).join(',');
          } else {
            parameters[key] = value.toString();
          }
        });
      }
    }

    if (search != null) {
      parameters[Api.search] = search;
    }

    if (sortBy != null) {
      parameters[Api.sortBy] = sortBy;
    }

    Map<String, dynamic> response =
        await Api.get(url: Api.getItemApi, queryParameters: parameters);

    List<ItemModel> items = (response['data']['data'] as List)
        .map((e) => ItemModel.fromJson(e))
        .toList();

    return DataOutput(total: response['data']['total'] ?? 0, modelList: items);
  }*/

  Future<DataOutput<ItemModel>> fetchPopularItems(
      {required String sortBy, required int page}) async {
    Map<String, dynamic> parameters = {Api.sortBy: sortBy, Api.page: page};

    Map<String, dynamic> response =
        await Api.get(url: Api.getItemApi, queryParameters: parameters);

    List<ItemModel> items = (response['data']['data'] as List)
        .map((e) => ItemModel.fromJson(e))
        .toList();

    return DataOutput(total: response['data']['total'] ?? 0, modelList: items);
  }

  Future<ItemModel> editItem(
    Map<String, dynamic> itemDetails,
    File? mainImage,
    List<File>? otherImages,
  ) async {
    Map<String, dynamic> parameters = {};
    parameters.addAll(itemDetails);

    if (mainImage != null) {
      MultipartFile image = await MultipartFile.fromFile(mainImage.path,
          filename: path.basename(mainImage.path));
      parameters['image'] = image;
    }

    if (otherImages != null && otherImages.isNotEmpty) {
      List<Future<MultipartFile>> futures = otherImages.map((imageFile) {
        return MultipartFile.fromFile(imageFile.path,
            filename: path.basename(imageFile.path));
      }).toList();

      List<MultipartFile> galleryImages = await Future.wait(futures);

      if (galleryImages.isNotEmpty) {
        parameters["gallery_images"] = galleryImages;
      }
    }

    Map<String, dynamic> response = await Api.post(
      url: Api.updateItemApi,
      parameter: parameters, /* useAuthToken: true*/
    );

    return _itemModelFromMutationResponse(response);
  }

  Future<void> deleteItem(int id) async {
    await Api.post(
      url: Api.deleteItemApi,
      parameter: {Api.id: id}, /* useAuthToken: true*/
    );
  }

  Future<void> itemTotalClick(int id) async {
    await Api.post(url: Api.setItemTotalClickApi, parameter: {Api.itemId: id});
  }

  Future<Map> makeAnOfferItem(int id, double? amount) async {
    Map response = await Api.post(
        url: Api.itemOfferApi,
        parameter: {Api.itemId: id, if (amount != null) Api.amount: amount});
    return response;
  }

  Future<DataOutput<ItemModel>> searchItem(
      String query, ItemFilterModel? filter,
      {required int page}) async {
    Map<String, dynamic> parameters = {
      Api.search: query,
      Api.page: page,
      if (filter != null) ...filter.toMap(),
    };

    if (filter != null) {
      if (filter.areaId == null) {
        parameters.remove('area_id');
      }
      parameters.remove('area');
      if (filter.customFields != null) {
        parameters.addAll(filter.customFields!);
      }
    }

    Map<String, dynamic> response =
        await Api.get(url: Api.getItemApi, queryParameters: parameters);

    List<ItemModel> items = (response['data']['data'] as List)
        .map((e) => ItemModel.fromJson(e))
        .toList();

    return DataOutput(total: response['data']['total'] ?? 0, modelList: items);
  }
}
