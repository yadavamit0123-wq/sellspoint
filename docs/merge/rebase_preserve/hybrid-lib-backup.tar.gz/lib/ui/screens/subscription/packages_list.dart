import 'dart:io';

import 'package:eClassify/data/cubits/subscription/assign_free_package_cubit.dart';
import 'package:eClassify/data/cubits/subscription/fetch_ads_listing_subscription_packages_cubit.dart';
import 'package:eClassify/data/cubits/subscription/fetch_featured_subscription_packages_cubit.dart';
import 'package:eClassify/data/cubits/system/fetch_system_settings_cubit.dart';
import 'package:eClassify/data/cubits/system/get_api_keys_cubit.dart';
import 'package:eClassify/data/model/subscription_pacakage_model.dart';
import 'package:eClassify/data/model/system_settings_model.dart';
import 'package:eClassify/settings.dart';
import 'package:eClassify/ui/screens/subscription/widget/featured_ads_subscription_plan_item.dart';
import 'package:eClassify/ui/screens/subscription/widget/item_listing_subscription_plans_item.dart';
import 'package:eClassify/ui/screens/widgets/animated_routes/blur_page_route.dart';
import 'package:eClassify/ui/screens/widgets/errors/no_data_found.dart';
import 'package:eClassify/ui/screens/widgets/errors/no_internet.dart';
import 'package:eClassify/ui/screens/widgets/errors/something_went_wrong.dart';
import 'package:eClassify/ui/screens/widgets/intertitial_ads_screen.dart';
import 'package:eClassify/ui/theme/theme.dart';
import 'package:eClassify/app_config.dart';
import 'package:eClassify/utils/api.dart';
import 'package:eClassify/utils/custom_text.dart';
import 'package:eClassify/utils/extensions/extensions.dart';
import 'package:eClassify/utils/hive_utils.dart';
import 'package:eClassify/utils/payment/gateaways/inapp_purchase_manager.dart';
import 'package:eClassify/utils/reel_subscription_admin.dart';
import 'package:eClassify/utils/reel_subscription_refresh.dart';
import 'package:eClassify/utils/subscription_navigation.dart';
import 'package:eClassify/utils/ui_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class SubscriptionPackageListScreen extends StatefulWidget {
  const SubscriptionPackageListScreen({
    super.key,
    this.categoryId,
    this.categoryName,
    this.highlightReelPlans = false,
  });

  final int? categoryId;
  final String? categoryName;
  final bool highlightReelPlans;

  static Route route(RouteSettings settings) {
    final args = settings.arguments as Map?;
    final categoryId = args?['categoryId'] as int?;
    final categoryName = args?['categoryName'] as String?;
    final highlightReelPlans = args?['highlightReelPlans'] == true;
    return BlurredRouter(builder: (context) {
      return MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => AssignFreePackageCubit(),
          ),
        ],
        child: SubscriptionPackageListScreen(
          categoryId: categoryId,
          categoryName: categoryName,
          highlightReelPlans: highlightReelPlans,
        ),
      );
    });
  }

  @override
  State<SubscriptionPackageListScreen> createState() =>
      _SubscriptionPackageListScreenState();
}

class _SubscriptionPackageListScreenState
    extends State<SubscriptionPackageListScreen>
    with SingleTickerProviderStateMixin {
  bool isLifeTimeSubscription = false;
  bool hasAlreadyPackage = false;
  bool isInterstitialAdShown = false;

  PageController adsPageController =
      PageController(initialPage: 0, viewportFraction: 0.8);
  PageController featuredPageController =
      PageController(initialPage: 0, viewportFraction: 0.8);

  int currentIndex = 0;
  late final TabController? _tabController;

  List<SubscriptionPackageModel> iapListingAdsProducts = [];
  List<String> listingAdsProducts = [];
  List<SubscriptionPackageModel> iapFeaturedAdsProducts = [];
  List<String> featuredAdsProducts = [];
  final InAppPurchaseManager _inAppPurchaseManager = InAppPurchaseManager();

  late final bool isFreeAdListingEnabled;
  bool _focusedReelPlanPage = false;
  @override
  void initState() {
    super.initState();
    ReelSubscriptionRefresh.onSubscriptionCatalogVisible();
    AdHelper.loadInterstitialAd();
    if (HiveUtils.isUserAuthenticated()) {
      context.read<GetApiKeysCubit>().fetch();
    }
    context
        .read<FetchAdsListingSubscriptionPackagesCubit>()
        .fetchPackages(categoryId: widget.categoryId);
    context
        .read<FetchFeaturedSubscriptionPackagesCubit>()
        .fetchPackages(categoryId: widget.categoryId);
    if (Platform.isIOS) {
      InAppPurchaseManager.getPending();
      _inAppPurchaseManager.listenIAP(context);
    }
    isFreeAdListingEnabled = context
            .read<FetchSystemSettingsCubit>()
            .getSetting(SystemSetting.freeAdListing) ==
        "1";
    if (!isFreeAdListingEnabled) {
      _tabController = TabController(length: 2, vsync: this);
      _tabController!.addListener(_handleTabSelection);
    } else {
      _tabController = null;
    }
  }

  @override
  void dispose() {
    if (_tabController != null) {
      _tabController?.removeListener(_handleTabSelection);
    }
    if (Platform.isIOS) {
      _inAppPurchaseManager.dispose();
    }
    super.dispose();
  }

  void _handleTabSelection() {
    if (_tabController!.indexIsChanging) {
      setState(() {
        currentIndex = 0;
      });
    }
  }

  void onPageChanged(int index) {
    setState(() {
      currentIndex = index; //update current index for Next button
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.color.backgroundColor,
      appBar: UiUtils.buildAppBar(
        context,
        showBackButton: true,
        title: widget.highlightReelPlans
            ? 'reelListingPlansTitle'.translate(context)
            : widget.categoryName?.isNotEmpty == true
                ? widget.categoryName!
                : AppConfig.enableSubscriptionListingScreenTitleV214
                    ? 'adsListingPlansTitle'.translate(context)
                    : 'subsctiptionPlane'.translate(context),
        bottomHeight: isFreeAdListingEnabled ? 0 : 49,
        actions: [
          if (AppConfig.enableSubscriptionPackageListActivePlansV214)
            TextButton(
              onPressed: () =>
                  SubscriptionNavigation.openActivePlans(context),
              child: CustomText(
                'activePlanLbl'.translate(context),
                color: context.color.territoryColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          if (Platform.isIOS)
            CupertinoButton(
                child: Text("restore".translate(context)),
                onPressed: () async {
                  await InAppPurchase.instance.restorePurchases();
                })
        ],
        bottom: isFreeAdListingEnabled
            ? null
            : [
                Container(
                  decoration: BoxDecoration(
                      color: context.color.secondaryColor,
                      // Set background color here
                      boxShadow: [
                        BoxShadow(
                          color:
                              context.color.borderColor.withValues(alpha: 0.8),
                          // Shadow color
                          spreadRadius: 3,
                          // Spread radius
                          blurRadius: 2,
                          // Blur radius
                          offset: Offset(0, 1), // Shadow offset
                        ),
                      ]),
                  child: TabBar(
                    controller: _tabController!,
                    tabs: [
                      Tab(text: "adsListing".translate(context)),
                      Tab(text: "featuredAdsLbl".translate(context)),
                    ],

                    indicatorColor: context.color.territoryColor,
                    // Line color
                    indicatorWeight: 3,

                    // Line thickness
                    labelColor: context.color.territoryColor,
                    // Selected tab text color
                    unselectedLabelColor:
                        context.color.textDefaultColor.withValues(alpha: 0.5),
                    // Unselected tab text color
                    labelStyle: TextStyle(
                      fontSize: 16,
                    ),
                    // Selected tab text style
                    labelPadding: EdgeInsets.symmetric(horizontal: 16),
                    // Padding around the tab text
                    indicatorSize: TabBarIndicatorSize.tab,
                  ),
                ),
              ],
      ),
      body: BlocListener<GetApiKeysCubit, GetApiKeysState>(
        listener: (context, state) {
          if (state is GetApiKeysSuccess) {
            AppSettings.stripeCurrency = state.stripeCurrency ?? "";
            AppSettings.stripePublishableKey = state.stripePublishableKey ?? "";
            AppSettings.stripeStatus = state.stripeStatus ?? 0;
            AppSettings.payStackCurrency = state.payStackCurrency ?? "";
            AppSettings.payStackKey = state.payStackApiKey ?? "";
            AppSettings.payStackStatus = state.payStackStatus ?? 0;
            AppSettings.razorpayKey = state.razorPayApiKey ?? "";
            AppSettings.razorpayStatus = state.razorPayStatus ?? 0;
            AppSettings.phonePeCurrency = state.phonePeCurrency ?? "";
            AppSettings.phonePeKey = state.phonePeKey ?? "";
            AppSettings.phonePeStatus = state.phonePeStatus ?? 0;

            AppSettings.updatePaymentGateways();
          }
        },
        child: isFreeAdListingEnabled
            ? featuredAds()
            : TabBarView(
                controller: _tabController!,
                children: [
                  adsListing(),
                  featuredAds(),
                ],
              ),
      ),
    );
  }

  Builder adsListing() {
    return Builder(builder: (context) {
      if (!isInterstitialAdShown) {
        AdHelper.showInterstitialAd();
        isInterstitialAdShown = true; // Update the flag
      }
      return BlocConsumer<FetchAdsListingSubscriptionPackagesCubit,
              FetchAdsListingSubscriptionPackagesState>(
          listener:
              (context, FetchAdsListingSubscriptionPackagesState state) {},
          builder: (context, state) {
            if (state is FetchAdsListingSubscriptionPackagesInProgress) {
              return Center(
                child: UiUtils.progress(),
              );
            }
            if (state is FetchAdsListingSubscriptionPackagesFailure) {
              if (state.errorMessage is ApiException) {
                if (state.errorMessage == "no-internet") {
                  return NoInternet(
                    onRetry: () {
                      context
                          .read<FetchAdsListingSubscriptionPackagesCubit>()
                          .fetchPackages();
                    },
                  );
                }
              }

              return const SomethingWentWrong();
            }
            if (state is FetchAdsListingSubscriptionPackagesSuccess) {
              if (state.subscriptionPackages.isEmpty) {
                return NoDataFound(
                  onTap: () {
                    context
                        .read<FetchAdsListingSubscriptionPackagesCubit>()
                        .fetchPackages();
                  },
                );
              }

              var packages = List<SubscriptionPackageModel>.from(
                state.subscriptionPackages,
              );
              if (widget.highlightReelPlans) {
                if (AppConfig.enableReelSubscriptionHideNonReelPlansV214) {
                  packages = packages
                      .where((p) => p.isReelAllowed == true)
                      .toList();
                  if (packages.isEmpty) {
                    return _ReelPlansEmptyState(
                      onRetry: () {
                        context
                            .read<FetchAdsListingSubscriptionPackagesCubit>()
                            .fetchPackages(categoryId: widget.categoryId);
                      },
                    );
                  }
                }
                // Client-side sort by [ReelSubscriptionAdmin.packageReelAllowedField].
                packages.sort((a, b) {
                  final ar = a.isReelAllowed == true ? 1 : 0;
                  final br = b.isReelAllowed == true ? 1 : 0;
                  return br.compareTo(ar);
                });
                if (!_focusedReelPlanPage) {
                  _focusedReelPlanPage = true;
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!mounted) return;
                    final idx =
                        packages.indexWhere((p) => p.isReelAllowed == true);
                    final target = idx >= 0 ? idx : 0;
                    if (adsPageController.hasClients) {
                      adsPageController.jumpToPage(target);
                      setState(() => currentIndex = target);
                    }
                  });
                }
              }

              return PageView.builder(
                  onPageChanged: onPageChanged,
                  //update index and fetch nex index details
                  controller: adsPageController,
                  itemBuilder: (context, index) {
                    return ItemListingSubscriptionPlansItem(
                      itemIndex: currentIndex,
                      index: index,
                      model: packages[index],
                      inAppPurchaseManager: _inAppPurchaseManager,
                      emphasizeReelHighlight: widget.highlightReelPlans,
                    );
                  },
                  itemCount: packages.length);
            }

            return Container();
          });
    });
  }

  Builder featuredAds() {
    return Builder(builder: (context) {
      if (!isInterstitialAdShown) {
        AdHelper.showInterstitialAd();
        isInterstitialAdShown = true; // Update the flag
      }
      return BlocConsumer<FetchFeaturedSubscriptionPackagesCubit,
              FetchFeaturedSubscriptionPackagesState>(
          listener: (context, FetchFeaturedSubscriptionPackagesState state) {},
          builder: (context, state) {
            if (state is FetchFeaturedSubscriptionPackagesInProgress) {
              return Center(
                child: UiUtils.progress(),
              );
            }
            if (state is FetchFeaturedSubscriptionPackagesFailure) {
              if (state.errorMessage is ApiException) {
                if (state.errorMessage == "no-internet") {
                  return NoInternet(
                    onRetry: () {
                      context
                          .read<FetchFeaturedSubscriptionPackagesCubit>()
                          .fetchPackages();
                    },
                  );
                }
              }

              return const SomethingWentWrong();
            }
            if (state is FetchFeaturedSubscriptionPackagesSuccess) {
              if (state.subscriptionPackages.isEmpty) {
                return NoDataFound(
                  onTap: () {
                    context
                        .read<FetchFeaturedSubscriptionPackagesCubit>()
                        .fetchPackages();
                  },
                );
              }

              return FeaturedAdsSubscriptionPlansItem(
                modelList: state.subscriptionPackages,
                inAppPurchaseManager: _inAppPurchaseManager,
              );
            }

            return Container();
          });
    });
  }
}

class _ReelPlansEmptyState extends StatelessWidget {
  const _ReelPlansEmptyState({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            NoDataFound(
              onTap: onRetry,
              mainMessage: 'reelNoReelPlansAvailable'.translate(context),
              subMessage: AppConfig.enableReelPlansEmptyAllListingCtaV214
                  ? 'reelNoReelPlansBrowseAllHint'.translate(context)
                  : null,
            ),
            if (AppConfig.enableReelPlansEmptyAllListingCtaV214) ...[
              const SizedBox(height: 20),
              UiUtils.buildButton(
                context,
                height: 44,
                radius: 10,
                buttonTitle: 'browseAdListingPlans'.translate(context),
                buttonColor: context.color.territoryColor,
                textColor: context.color.secondaryColor,
                onPressed: () {
                  SubscriptionNavigation.openItemListingPackages(context);
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}
